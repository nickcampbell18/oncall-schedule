require 'faraday'
require 'json'
require 'typhoeus/adapters/faraday'

require_relative 'oncall/configuration'
require_relative 'oncall/users'