whos-on-call
============

A small sinatra app which plugs into your Pagerduty account and provides a simple dashboard for who is currently on call.

Adding/removing groups
======================

Groups are defined in two places - environment variables, and [server.rb](server.rb). Here is an example of the Rails group, and how it is configured:

```
# Environment variables
# RAILS_PRIMARY is the first schedule group for the "Rails" on-call scenario
RAILS_PRIMARY=PM7LWKU
# RAILS_SECONDARY is the group which receives cascade notifications when the primary does not acknowledge.
RAILS_SECONDARY=PI3UE03
```

```ruby
# server.rb
OnCall.configure do |o|
  o.groups = {
    rails: [
      # The order here is significant: the first entry is a primary, the second entry is the secondary
      ENV.fetch('RAILS_PRIMARY'),
      ENV.fetch('RAILS_SECONDARY')
    ]
  }
end
```

If you want to add a specific colour to your group, you'll also need to add an entry in [our css file](public/global.css)
```css
  section .group.rails {
    color: #BE80FF;
  }
```

Running locally
===============

To run whos-on-call locally, first rename the ".env.sample" file to ".env". You'll need a Pagerduty API token to make requests (a Pagerduty admin, e.g. Ops should be able to grant one of these), and set that token as `PAGER_TOKEN` in the ".env" file.

Then, you can use `rackup` to run the application.

Pushing changes to Heroku
=========================

Github should always be the canonical source code for the application, but because it is hosted on Heroku we maintain a mirror there as well. Deploying to heroku is as simple as `git push heroku master`.

First, you should ensure you have push access to the heroku repository. The application is owned by "ops@yammer-inc.com", but there are several collaborators (Nick Campbell, Mike O'Neill, Grace Chang) who should be able to grant you access.

Second, add `heroku` as a remote to your git config, like so: `git remote add heroku git@heroku.com:whos-on-call.git`.

Third, if you changed any environment variables (added groups, etc), make sure you update these on heroku as well. Use `heroku config:set VARIABLE=parameter,..` as needed. `heroku config` will show you all the existing variables if you need an example.

Finally, do `git push heroku master`. If all worked, your changes should propogate shortly - if it failed, you should roll back to a known good state, using the [web interface](https://dashboard.heroku.com/apps/whos-on-call/activity).