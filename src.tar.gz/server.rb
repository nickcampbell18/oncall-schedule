require_relative './lib/oncall'
require 'sinatra/base'
require 'rack-cache'
require 'dalli'

OnCall.configure do |o|
  o.groups = {
    oncall_tl: [ENV.fetch('ONCALL_LEAD')],
    rails: [
      ENV.fetch('RAILS_PRIMARY'),
      ENV.fetch('RAILS_SECONDARY')
    ],
    cs: [
      ENV.fetch('CS_PRIMARY'),
      ENV.fetch('CS_SECONDARY')
    ],
    ops: [
      ENV.fetch('OPS_PRIMARY'),
      ENV.fetch('OPS_SECONDARY')
    ],
    infra: [ENV.fetch('INFRA_GROUP')],
    irt_mgr: [ENV.fetch('INCIDENT_MANAGER')],
    frontend: [
      ENV.fetch('FE_PRIMARY'),
      ENV.fetch('FE_SECONDARY')
    ],
    data: [
      ENV.fetch('DATA_PRIMARY'),
      ENV.fetch('DATA_SECONDARY')
    ],
    qa: [ENV.fetch('QA_PRIMARY')]
  }
  o.pager_token = ENV.fetch('PAGER_TOKEN')
  o.pager_url   = ENV.fetch('PAGER_URL')
end

class OnCall::Server < Sinatra::Base

  CACHE_EXPIRES = ENV.fetch('RACK_CACHE_TIME', 5) # 5 seconds

  configure :production do
    require 'newrelic_rpm'
  end

  before do
    cache_control :public, :must_revalidate, max_age: CACHE_EXPIRES
  end

  set :static_cache_control, [:public, :max_age => 120]

  get '/' do
    @users = OnCall::Users.all
    erb :now
  end

  get '/now' do
    content_type :json
    OnCall::Users.all.to_json
  end

end
